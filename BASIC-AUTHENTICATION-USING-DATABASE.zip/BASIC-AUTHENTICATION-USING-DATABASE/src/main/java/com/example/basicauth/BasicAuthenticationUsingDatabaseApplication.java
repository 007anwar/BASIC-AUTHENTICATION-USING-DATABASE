package com.example.basicauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicAuthenticationUsingDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicAuthenticationUsingDatabaseApplication.class, args);
	}

}
