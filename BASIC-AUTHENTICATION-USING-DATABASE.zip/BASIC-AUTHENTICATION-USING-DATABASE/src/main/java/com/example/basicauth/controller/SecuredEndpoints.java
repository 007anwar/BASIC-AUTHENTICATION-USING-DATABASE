package com.example.basicauth.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/secured")
public class SecuredEndpoints {

    @RequestMapping("/useradmin")
    public String userAdmin()
    {
        return "Can be accessed by user and admin";
    }

    @RequestMapping("/user")
    public String userAdminCopy()
    {
        return "Can be accessed by user";
    }

    @RequestMapping("/admin")
    public String admin()
    {
        return "Can be accessed by admin";
    }

}
