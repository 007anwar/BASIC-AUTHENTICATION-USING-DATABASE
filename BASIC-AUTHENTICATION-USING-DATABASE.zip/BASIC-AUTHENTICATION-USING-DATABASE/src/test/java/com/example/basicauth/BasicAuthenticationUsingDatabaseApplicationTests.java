package com.example.basicauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicAuthenticationUsingDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
